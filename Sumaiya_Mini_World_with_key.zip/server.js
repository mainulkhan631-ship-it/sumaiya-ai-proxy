import express from "express";
import fetch from "node-fetch";
import cors from "cors";

const app = express();
app.use(cors());
app.use(express.json());

const OPENAI_KEY = "YOUR_OPENAI_API_KEY"; // Recommended: keep secret in environment variables

app.post("/ask", async (req, res) => {
    const { question } = req.body;
    if (!question) return res.status(400).json({ error: "No question provided" });

    try {
        const response = await fetch("https://api.openai.com/v1/chat/completions", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${OPENAI_KEY}`
            },
            body: JSON.stringify({
                model: "gpt-3.5-turbo",
                messages: [
                    { role: "system", content: "আপনি একজন রান্নার সহায়ক AI।" },
                    { role: "user", content: question }
                ],
                max_tokens: 200
            })
        });
        const data = await response.json();
        res.json({ answer: data.choices[0].message.content });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: "AI server error" });
    }
});

app.listen(process.env.PORT || 5000, () => console.log("Server running"));
SUMAIYA MINI WORLD - HOPWEB READY (CLIENT-SIDE API KEY EMBEDDED)

Files:
1. index.html - Hopweb-ready frontend (API key embedded in the page)
2. server.js - Optional server example (use env var for OPENAI_KEY)
3. README.txt - Setup and security notes

IMPORTANT SECURITY NOTE:
- index.html currently contains your OpenAI API key inside the JS. This is INSECURE.
  Anyone who opens the webpage or views source can see and misuse your key.
- Recommended: create a server (Render/Railway/Vercel) and keep the API key on server-side,
  or rotate/delete this key after testing.
- If this is for public use, remove the key immediately and use a server-side proxy.

How to use (quick):
1. Upload index.html to Hopweb (New Project -> Upload file).
2. Open the Hopweb URL -> you can ask the AI directly from the page.
3. To stop public exposure, revoke or rotate the API key on your OpenAI dashboard.

If you want, I can now:
- produce a version that uses a server-side proxy (safer), and help you host it on Render/Railway.
- or remove the embedded key and provide instructions to plug in the key manually later.
